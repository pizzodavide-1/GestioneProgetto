Arduino-Serial-Communication
============================

Simple Arduino Serial Communication in C#

![alt text](http://i.imgur.com/vNVeH5B.png "Preview")
