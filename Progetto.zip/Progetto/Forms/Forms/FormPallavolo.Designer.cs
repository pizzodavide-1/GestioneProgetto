﻿namespace Forms
{
    partial class FormPallavolo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.SetTeam2 = new System.Windows.Forms.Label();
            this.SetTeam1 = new System.Windows.Forms.Label();
            this.PunteggioTeam2 = new System.Windows.Forms.Label();
            this.PunteggioTeam1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.SetTeam2);
            this.panel1.Controls.Add(this.SetTeam1);
            this.panel1.Controls.Add(this.PunteggioTeam2);
            this.panel1.Controls.Add(this.PunteggioTeam1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1065, 517);
            this.panel1.TabIndex = 3;
            // 
            // SetTeam2
            // 
            this.SetTeam2.AutoSize = true;
            this.SetTeam2.Font = new System.Drawing.Font("Microsoft Sans Serif", 37.25F);
            this.SetTeam2.ForeColor = System.Drawing.Color.Red;
            this.SetTeam2.Location = new System.Drawing.Point(941, 201);
            this.SetTeam2.Name = "SetTeam2";
            this.SetTeam2.Size = new System.Drawing.Size(53, 58);
            this.SetTeam2.TabIndex = 5;
            this.SetTeam2.Text = "0";
            // 
            // SetTeam1
            // 
            this.SetTeam1.AutoSize = true;
            this.SetTeam1.Font = new System.Drawing.Font("Microsoft Sans Serif", 37.25F);
            this.SetTeam1.ForeColor = System.Drawing.Color.Red;
            this.SetTeam1.Location = new System.Drawing.Point(99, 201);
            this.SetTeam1.Name = "SetTeam1";
            this.SetTeam1.Size = new System.Drawing.Size(53, 58);
            this.SetTeam1.TabIndex = 4;
            this.SetTeam1.Text = "0";
            // 
            // PunteggioTeam2
            // 
            this.PunteggioTeam2.AutoSize = true;
            this.PunteggioTeam2.Font = new System.Drawing.Font("Microsoft Sans Serif", 55.25F);
            this.PunteggioTeam2.Location = new System.Drawing.Point(767, 280);
            this.PunteggioTeam2.Name = "PunteggioTeam2";
            this.PunteggioTeam2.Size = new System.Drawing.Size(119, 85);
            this.PunteggioTeam2.TabIndex = 3;
            this.PunteggioTeam2.Text = "00";
            this.PunteggioTeam2.UseMnemonic = false;
            // 
            // PunteggioTeam1
            // 
            this.PunteggioTeam1.AutoSize = true;
            this.PunteggioTeam1.Font = new System.Drawing.Font("Microsoft Sans Serif", 55.25F);
            this.PunteggioTeam1.Location = new System.Drawing.Point(162, 280);
            this.PunteggioTeam1.Name = "PunteggioTeam1";
            this.PunteggioTeam1.Size = new System.Drawing.Size(119, 85);
            this.PunteggioTeam1.TabIndex = 2;
            this.PunteggioTeam1.Text = "00";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 40.25F);
            this.label1.Location = new System.Drawing.Point(96, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(275, 63);
            this.label1.TabIndex = 0;
            this.label1.Text = "Squadra 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 40.25F);
            this.label2.Location = new System.Drawing.Point(719, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(275, 63);
            this.label2.TabIndex = 1;
            this.label2.Text = "Squadra 2";
            // 
            // FormPallavolo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1089, 541);
            this.Controls.Add(this.panel1);
            this.MaximumSize = new System.Drawing.Size(1105, 580);
            this.MinimumSize = new System.Drawing.Size(1105, 580);
            this.Name = "FormPallavolo";
            this.Text = "FormPallavolo";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label SetTeam2;
        private System.Windows.Forms.Label SetTeam1;
        private System.Windows.Forms.Label PunteggioTeam2;
        private System.Windows.Forms.Label PunteggioTeam1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}