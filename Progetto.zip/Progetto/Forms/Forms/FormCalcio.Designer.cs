﻿namespace Forms
{
    partial class FormCalcio
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Timer = new System.Windows.Forms.Label();
            this.labelTempo = new System.Windows.Forms.Label();
            this.PunteggioTeam2 = new System.Windows.Forms.Label();
            this.PunteggioTeam1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30.25F);
            this.label1.Location = new System.Drawing.Point(30, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(210, 47);
            this.label1.TabIndex = 0;
            this.label1.Text = "Squadra 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 30.25F);
            this.label2.Location = new System.Drawing.Point(794, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(210, 47);
            this.label2.TabIndex = 1;
            this.label2.Text = "Squadra 2";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Timer);
            this.panel1.Controls.Add(this.labelTempo);
            this.panel1.Controls.Add(this.PunteggioTeam2);
            this.panel1.Controls.Add(this.PunteggioTeam1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(12, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1065, 516);
            this.panel1.TabIndex = 2;
            // 
            // Timer
            // 
            this.Timer.AutoSize = true;
            this.Timer.Font = new System.Drawing.Font("Microsoft Sans Serif", 55.25F);
            this.Timer.Location = new System.Drawing.Point(414, 277);
            this.Timer.Name = "Timer";
            this.Timer.Size = new System.Drawing.Size(222, 85);
            this.Timer.TabIndex = 5;
            this.Timer.Text = "00:00";
            // 
            // labelTempo
            // 
            this.labelTempo.AutoSize = true;
            this.labelTempo.Font = new System.Drawing.Font("Microsoft Sans Serif", 37.25F);
            this.labelTempo.Location = new System.Drawing.Point(403, 17);
            this.labelTempo.Name = "labelTempo";
            this.labelTempo.Size = new System.Drawing.Size(243, 58);
            this.labelTempo.TabIndex = 4;
            this.labelTempo.Text = "1° Tempo";
            // 
            // PunteggioTeam2
            // 
            this.PunteggioTeam2.AutoSize = true;
            this.PunteggioTeam2.Font = new System.Drawing.Font("Microsoft Sans Serif", 52.25F);
            this.PunteggioTeam2.Location = new System.Drawing.Point(866, 167);
            this.PunteggioTeam2.Name = "PunteggioTeam2";
            this.PunteggioTeam2.Size = new System.Drawing.Size(73, 79);
            this.PunteggioTeam2.TabIndex = 3;
            this.PunteggioTeam2.Text = "0";
            this.PunteggioTeam2.UseMnemonic = false;
            // 
            // PunteggioTeam1
            // 
            this.PunteggioTeam1.AutoSize = true;
            this.PunteggioTeam1.Font = new System.Drawing.Font("Microsoft Sans Serif", 52.25F);
            this.PunteggioTeam1.Location = new System.Drawing.Point(89, 157);
            this.PunteggioTeam1.Name = "PunteggioTeam1";
            this.PunteggioTeam1.Size = new System.Drawing.Size(73, 79);
            this.PunteggioTeam1.TabIndex = 2;
            this.PunteggioTeam1.Text = "0";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // FormCalcio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1089, 541);
            this.Controls.Add(this.panel1);
            this.MaximumSize = new System.Drawing.Size(1105, 580);
            this.MinimumSize = new System.Drawing.Size(1105, 580);
            this.Name = "FormCalcio";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelTempo;
        private System.Windows.Forms.Label PunteggioTeam2;
        private System.Windows.Forms.Label PunteggioTeam1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label Timer;
    }
}

