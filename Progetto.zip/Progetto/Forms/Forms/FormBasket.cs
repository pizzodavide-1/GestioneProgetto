﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms
{
    public partial class FormBasket : Form
    {
        public int _countS = 0;
        public int _countM = 0;
        public int _period=1;
        public FormBasket()
        {
            InitializeComponent();
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (_period == 1)
            {
                labelPeriod1.BackColor = Color.Red;
            }
            else if (_period == 2)
            {
                labelPeriod1.BackColor = Color.Transparent;
                labelPeriod2.BackColor = Color.Red;
            }
            else if (_period == 3)
            {
                labelPeriod1.BackColor = Color.Transparent;
                labelPeriod2.BackColor = Color.Transparent;
                labelPeriod3.BackColor = Color.Red;
            }
            else if (_period == 4) {
                labelPeriod1.BackColor = Color.Transparent;
                labelPeriod2.BackColor = Color.Transparent;
                labelPeriod3.BackColor = Color.Transparent;
                labelPeriod4.BackColor = Color.Red;
            }
            if (_countM == 10)
            {

                _period++;
                _countM = 0;
                _countS = 0;
            }
            _countS++;
            if (_countS == 60)
            {
                
                _countS = 0;
                _countM++;

                if (_countM < 10)
                {
                    Timer.Text = "0" + _countM.ToString() + ":" + _countS.ToString();
                    if (_countS < 10)
                    {
                        Timer.Text = "0" + _countM.ToString() + ":" + "0" + _countS.ToString();
                    }
                    else
                    {
                        Timer.Text = "0" + _countM.ToString() + ":" + _countS.ToString();
                    }
                }
                else
                {
                    Timer.Text = _countM.ToString() + ":" + _countS.ToString();
                }
            }
            else
            {
                if (_countM < 10)
                {
                    Timer.Text = "0" + _countM.ToString() + ":" + _countS.ToString();
                    if (_countS < 10)
                    {
                        Timer.Text = "0" + _countM.ToString() + ":" + "0" + _countS.ToString();
                    }
                    else
                    {
                        Timer.Text = "0" + _countM.ToString() + ":" + _countS.ToString();
                    }
                }
                else
                {
                    Timer.Text = _countM.ToString() + ":" + _countS.ToString();
                }

            }
        }
    }
}
